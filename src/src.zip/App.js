import './App.css';
import { useState } from 'react';
import Content from './Content/Content';


function App() {
  
  return (
    <div className="App">
      <Content/>
    </div>
  );
}

export default App;
