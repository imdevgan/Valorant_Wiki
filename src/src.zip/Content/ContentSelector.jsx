import React from "react";

function ContentSelector({setContent}) {
  return (
    <div>
        <button onClick={setContent('agents')}>Agents</button>
        <button onClick={setContent('buddies')}>Buddies</button>
        <button>Bundles</button>
        <button>Maps</button>
        <button>Player_Cards</button>
        <button>Sprays</button>
        <button>Weapons</button>
    </div>
  );
}

export default ContentSelector;
